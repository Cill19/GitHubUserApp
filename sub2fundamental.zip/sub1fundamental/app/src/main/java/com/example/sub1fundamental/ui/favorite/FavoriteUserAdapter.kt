package com.example.sub1fundamental.ui.favorite

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.sub1fundamental.data.remote.response.GithubUser
import com.example.sub1fundamental.databinding.ItemUserBinding

class FavoriteUserAdapter(private val onItemClickCallback: OnItemClickCallback) : ListAdapter<GithubUser, FavoriteUserAdapter.MyViewHolder>(DIFF_CALLBACK) {

	override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
		val binding = ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
		return MyViewHolder(binding, onItemClickCallback)
	}

	override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
		val user = getItem(position)
		holder.bind(user)
	}
	class MyViewHolder(private val binding: ItemUserBinding, private val onItemClickCallback: OnItemClickCallback) : RecyclerView.ViewHolder(binding.root) {
		@SuppressLint("SetTextI18n")
		fun bind(user: GithubUser){
			binding.root.setOnClickListener {
				onItemClickCallback.onItemClicked(user)
			}

			binding.apply {
				Glide.with(itemView)
					.load(user.avatarUrl)
					.centerCrop()
					.into(imgItemPhoto)
				tvItemName.text = user.login
				tvItemId.text = "User ID: ${user.id}"
			}
		}
	}

	companion object {
		val DIFF_CALLBACK = object : DiffUtil.ItemCallback<GithubUser
				>() {
			override fun areItemsTheSame(oldItem: GithubUser, newItem: GithubUser): Boolean {
				return oldItem == newItem
			}
			override fun areContentsTheSame(oldItem: GithubUser, newItem: GithubUser): Boolean {
				return oldItem == newItem
			}
		}
	}

	interface OnItemClickCallback{
		fun onItemClicked(data: GithubUser)
	}
}