package com.example.sub1fundamental.ui.splashscreen

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.example.sub1fundamental.databinding.ActivitySplashscreenBinding
import com.example.sub1fundamental.ui.home.MainActivity

@Suppress("DEPRECATION")
@SuppressLint("CustomSplashScreen")
class SplashscreenActivity : AppCompatActivity() {

	private lateinit var binding: ActivitySplashscreenBinding

	@SuppressLint("AppCompatMethod")
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)

		// Menghilangkan title bar
		requestWindowFeature(Window.FEATURE_NO_TITLE)
		supportActionBar?.hide()

		binding = ActivitySplashscreenBinding.inflate(layoutInflater)
		setContentView(binding.root)

		// Mengatur layar menjadi full screen
		window.setFlags(
			WindowManager.LayoutParams.FLAG_FULLSCREEN,
			WindowManager.LayoutParams.FLAG_FULLSCREEN
		)

		// Membuat variabel untuk splashscreen handler
		val handler = Handler()
		handler.postDelayed({

			val intent = Intent(this@SplashscreenActivity, MainActivity::class.java)
			startActivity(intent)
			finish()

		}, 3000) // Menampilkan splash screen selama 3 detik
	}
}
