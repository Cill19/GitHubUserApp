package com.example.sub1fundamental.ui.detail

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.sub1fundamental.databinding.FragmentBackBinding
import com.example.sub1fundamental.data.remote.response.DetailUserResponse
import com.example.sub1fundamental.ui.viewmodel.DetailViewModel

class FollowFragment : Fragment() {
    private var _binding: FragmentBackBinding? = null
    private val binding get() = _binding!!
    private val viewModel by viewModels<DetailViewModel>()
    private var position: Int? = null
    private var username: String? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBackBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        arguments?.let {
            position = it.getInt(ARG_POSITION)
            username = it.getString(ARG_USERNAME)
        }
        binding.rvReview.layoutManager = LinearLayoutManager(requireActivity())
        viewModel.isloading.observe(viewLifecycleOwner) {
            showLoading(it)
        }
        if (position == 1) {
            viewModel.followinguser(username.toString())
            getResult()
        } else {
            viewModel.followersuser(username.toString())
            getResult()
        }
    }

    private fun getResult() {
        viewModel.follow.observe(viewLifecycleOwner) { data ->
            val adapter = FollowAdapter(data)
            binding.rvReview.adapter = adapter
            adapter.setOnItemClick(object : FollowAdapter.OnItemClick {
                override fun onitemclicked(data: DetailUserResponse) {
//                    val intent = Intent(activity, DetailActivity::class.java)
//                    intent.putExtra(MainActivity.extras_user, data.login)
//                    startActivity(intent)
                }
            })
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        const val ARG_POSITION = "arg_position"
        const val ARG_USERNAME = "arg_username"
    }
}
