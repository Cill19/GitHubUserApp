package com.example.sub1fundamental.ui.favorite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.sub1fundamental.data.local.database.FavoriteUser
import com.example.sub1fundamental.data.local.datastore.DataStoreManager
import com.example.sub1fundamental.data.remote.response.GithubUser
import com.example.sub1fundamental.databinding.ActivityFavoriteUserBinding
import com.example.sub1fundamental.ui.detail.DetailActivity
import com.example.sub1fundamental.ui.settings.ThemeSettingsViewModel

class FavoriteUserActivity : AppCompatActivity() {

	private var _binding: ActivityFavoriteUserBinding? = null
	private val binding get() = _binding!!

	private lateinit var userAdapter: FavoriteUserAdapter
	private lateinit var viewModel: FavoriteUserViewModel

	private val settingsViewModel by viewModels<ThemeSettingsViewModel> {
		ThemeSettingsViewModel.Factory(DataStoreManager(this))
	}

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		_binding = ActivityFavoriteUserBinding.inflate(layoutInflater)
		setContentView(binding.root)

		// Enable the up navigation (back button)
		supportActionBar?.setDisplayHomeAsUpEnabled(true)
		title = "Favorites User"

		viewModel = ViewModelProvider(this)[FavoriteUserViewModel::class.java]

		userAdapter = FavoriteUserAdapter(object : FavoriteUserAdapter.OnItemClickCallback {
			override fun onItemClicked(data: GithubUser) {
				val intent = Intent(this@FavoriteUserActivity, DetailActivity::class.java)
				intent.putExtra(DetailActivity.EXTRA_USERNAME, data.login)
				intent.putExtra(DetailActivity.EXTRA_ID, data.id)
				intent.putExtra(DetailActivity.EXTRA_URL, data.avatarUrl)
				startActivity(intent)
			}
		})

		binding.apply {
			rvUser.setHasFixedSize(true)
			rvUser.layoutManager = LinearLayoutManager(this@FavoriteUserActivity)
			rvUser.adapter = userAdapter
		}

		viewModel.getFavoriteUser()?.observe(this) { favoriteUsers ->
			val githubUsers = mapFavoriteUsersToGithubUsers(favoriteUsers)
			userAdapter.submitList(githubUsers)
		}

		themeSettings()
	}

	private fun themeSettings() {
		settingsViewModel.getTheme().observe(this) { isDarkTheme ->
			val nightMode = if (isDarkTheme) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
			AppCompatDelegate.setDefaultNightMode(nightMode)
			Log.d("THEME", isDarkTheme.toString())
		}
	}

	private fun mapFavoriteUsersToGithubUsers(favoriteUsers: List<FavoriteUser>): List<GithubUser> {
		return favoriteUsers.map { user ->
			GithubUser(
				user.login,
				htmlUrl = user.avatar_url,
				id = user.id,
				avatarUrl = user.avatar_url
			)
		}
	}

	override fun onOptionsItemSelected(item: MenuItem): Boolean {
		return when (item.itemId) {
			android.R.id.home -> {
				// Handle the up button click, e.g., navigate back
				onBackPressed()
				true
			}
			else -> super.onOptionsItemSelected(item)
		}
	}

	override fun onDestroy() {
		super.onDestroy()
		_binding = null
	}
}
