package com.example.sub1fundamental.ui.home

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.sub1fundamental.R
import com.example.sub1fundamental.data.local.datastore.DataStoreManager
import com.google.android.material.snackbar.Snackbar
import com.example.sub1fundamental.data.remote.response.DetailUserResponse
import com.example.sub1fundamental.ui.detail.DetailActivity
import com.example.sub1fundamental.ui.viewmodel.MainViewModel
import com.example.sub1fundamental.databinding.ActivityMainBinding
import com.example.sub1fundamental.ui.favorite.FavoriteUserActivity
import com.example.sub1fundamental.ui.settings.ThemeSettingsActivity
import com.example.sub1fundamental.ui.settings.ThemeSettingsViewModel

class MainActivity : AppCompatActivity() {

    private var _binding: ActivityMainBinding? = null
    private val binding get() = _binding!!
    private val viewModel by viewModels<MainViewModel>()

    private val settingsViewModel by viewModels<ThemeSettingsViewModel> {
        ThemeSettingsViewModel.Factory(DataStoreManager(this))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupSearchBar()
        setupRecyclerView()

        viewModel.message.observe(this) {
            it.getContentIfNotHandled()?.let { text ->
                Snackbar.make(window.decorView.rootView, text, Snackbar.LENGTH_SHORT).show()
            }
        }
        viewModel.isloading.observe(this) { showLoading(it) }

        themeSettings()
    }

    private fun setupSearchBar() {
        binding.searchBar.inflateMenu(R.menu.option_menu)
        binding.searchBar.setOnMenuItemClickListener { menuItem ->
            return@setOnMenuItemClickListener when (menuItem.itemId) {
                R.id.favorite_menu -> {
                    val intent = Intent(this@MainActivity, FavoriteUserActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.setting_menu -> {
                    val intent = Intent(this@MainActivity, ThemeSettingsActivity::class.java)
                    startActivity(intent)
                    true
                }
                else -> true
            }
        }

        binding.searchView.setupWithSearchBar(binding.searchBar)
        binding.searchView.editText.setOnEditorActionListener { textView, actionId, event ->
            binding.searchBar.text = binding.searchView.text
            binding.searchView.hide()
            binding.progressBar.visibility = View.VISIBLE
            viewModel.getuser(binding.searchView.text.toString())
            false
        }
    }

    private fun setupRecyclerView() {
        binding.rvGithub.layoutManager = LinearLayoutManager(this)
        viewModel.user.observe(this) { data ->
            val adapter = MainAdapter(data)
            binding.rvGithub.adapter = adapter
            adapter.setOnItemClick(object : MainAdapter.OnItemClick {
                override fun onitemclicked(data: DetailUserResponse) {
                    val intent = Intent(this@MainActivity, DetailActivity::class.java)
                    intent.putExtra(DetailActivity.EXTRA_USERNAME, data.login)
                    intent.putExtra(DetailActivity.EXTRA_ID, data.id)
                    intent.putExtra(DetailActivity.EXTRA_URL, data.avatarUrl)
                    startActivity(intent)
                }
            })
        }
    }

    private fun themeSettings() {
        settingsViewModel.getTheme().observe(this) { isDarkTheme ->
            val nightMode = if (isDarkTheme) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
            AppCompatDelegate.setDefaultNightMode(nightMode)
            Log.d("THEME", isDarkTheme.toString())
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        binding.rvGithub.visibility = if (!isLoading) View.VISIBLE else View.GONE
    }

    companion object {
        const val extras_user = "extras_user"
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}
