package com.example.sub1fundamental.ui.detail

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.sub1fundamental.R
import com.example.sub1fundamental.data.local.datastore.DataStoreManager
import com.example.sub1fundamental.databinding.ActivityDetailBinding
import com.example.sub1fundamental.ui.settings.ThemeSettingsViewModel
import com.example.sub1fundamental.ui.viewmodel.DetailViewModel
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.properties.Delegates

class DetailActivity : AppCompatActivity() {
	companion object {
		@StringRes
		val TAB_TITLES = intArrayOf(
			R.string.following,
			R.string.follower
		)

		const val EXTRA_USERNAME = "extra_username"
		const val EXTRA_ID = "extra_id"
		const val EXTRA_URL = "extra_url"
	}

	private var id by Delegates.notNull<Int>()
	private lateinit var username: String
	private lateinit var avatarUrl: String

	private val viewModel by viewModels<DetailViewModel>()

	private var _binding: ActivityDetailBinding? = null
	private val binding get() = _binding!!

	private val settingsViewModel by viewModels<ThemeSettingsViewModel> {
		ThemeSettingsViewModel.Factory(DataStoreManager(this))
	}

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		_binding = ActivityDetailBinding.inflate(layoutInflater)
		setContentView(binding.root)

		val username = intent.getStringExtra(EXTRA_USERNAME)

		// Enable the up navigation (back button)
		supportActionBar?.setDisplayHomeAsUpEnabled(true)
		title = username

		username?.let {
			setupViewPager(it)
			setupActionBar()
			viewModel.isloading.observe(this) { showLoading(it) }
			getDetail(it)
		}

		getDataUser()

		addUserToFavorite()

		themeSettings()
	}

	private fun themeSettings() {
		settingsViewModel.getTheme().observe(this) {
			val nightMode = if (it) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
			AppCompatDelegate.setDefaultNightMode(nightMode)
		}
	}

	private fun getDataUser() {
		username = intent.getStringExtra(EXTRA_USERNAME)!!
		id = intent.getIntExtra(EXTRA_ID, 0)
		avatarUrl = intent.getStringExtra(EXTRA_URL)!!

		Log.d("USERID", id.toString())
		Log.d("USERNAME", username)
	}

	private fun addUserToFavorite() {
		var _isChecked = false
		CoroutineScope(Dispatchers.IO).launch {
			val count = viewModel.checkUser(id)
			withContext(Dispatchers.Main) {
				if (count != null) {
					if (count > 0) {
						binding.toggleFavorite.isChecked = true
						_isChecked = true
					} else {
						binding.toggleFavorite.isChecked = false
						_isChecked = false
					}
				}
			}
		}

		binding.toggleFavorite.setOnClickListener {
			_isChecked = !_isChecked
			if (_isChecked) {
				viewModel.addToFavorite(username, id, avatarUrl)
				Toast.makeText(this, "$username is added to favorites!", Toast.LENGTH_SHORT).show()
			} else {
				viewModel.removeFromFavorite(id)
				Toast.makeText(this, "$username is removed from favorites!", Toast.LENGTH_SHORT).show()
			}
			binding.toggleFavorite.isChecked = _isChecked
		}
	}

	private fun setupViewPager(username: String) {
		val sectionsPagerAdapter = SectionsPagerAdapter(this)
		val viewPager: ViewPager2 = findViewById(R.id.view_pager)
		sectionsPagerAdapter.username = username
		viewPager.adapter = sectionsPagerAdapter

		val tabs: TabLayout = findViewById(R.id.tabs)
		TabLayoutMediator(tabs, viewPager) { tab, position ->
			tab.text = resources.getString(TAB_TITLES[position])
		}.attach()
	}

	private fun setupActionBar() {
		supportActionBar?.elevation = 0f
	}

	@SuppressLint("SetTextI18n")
	private fun getDetail(username: String) {
		viewModel.detailuser(username)
		viewModel.user.observe(this) { data ->
			Glide.with(this).load(data.avatarUrl).into(binding.imgItemPhoto)
			binding.tvDetailName.text = data.name
			binding.tvDetailUsername.text = data.login
			binding.folowing.text = "${data.following} following"
			binding.folowers.text = "${data.followers} followers"
		}
	}

	private fun showLoading(isLoading: Boolean) {
		binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
	}

	override fun onDestroy() {
		super.onDestroy()
		_binding = null
	}

	override fun onOptionsItemSelected(item: MenuItem): Boolean {
		return when (item.itemId) {
			android.R.id.home -> {
				// Handle the up button click, e.g., navigate back
				onBackPressed()
				true
			}

			else -> super.onOptionsItemSelected(item)
		}
	}
}
