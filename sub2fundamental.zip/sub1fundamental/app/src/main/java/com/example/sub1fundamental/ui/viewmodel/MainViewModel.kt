package com.example.sub1fundamental.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.sub1fundamental.helper.Event
import com.example.sub1fundamental.data.remote.response.DetailUserResponse
import com.example.sub1fundamental.data.remote.response.GithubResponse
import com.example.sub1fundamental.data.remote.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel : ViewModel () {
    private val _user = MutableLiveData<List<DetailUserResponse>>()
    val user:LiveData<List<DetailUserResponse>> = _user
    private val _isloading = MutableLiveData<Boolean>()
    val isloading:LiveData<Boolean> = _isloading
    private val _message = MutableLiveData<Event<String>>()
    val message:LiveData<Event<String>> = _message

    init {
        getuser()
    }
    fun getuser(username:String="arif"){
        _isloading.value = true
        val client = ApiConfig.getApiService().getSearch(username)
        client.enqueue(object:Callback<GithubResponse>{
            override fun onResponse(
                call: Call<GithubResponse>,
                response: Response<GithubResponse>
            ) {
                _isloading.value = false
                if (response.isSuccessful){
                    _user.value = response.body()?.items
                }
            }

            override fun onFailure(call: Call<GithubResponse>, t: Throwable) {
                _isloading.value = false
                _message.value = Event(t.message.toString())

            }
        })
    }
}