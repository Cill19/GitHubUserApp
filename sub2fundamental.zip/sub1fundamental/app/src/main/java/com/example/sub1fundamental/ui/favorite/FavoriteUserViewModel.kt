package com.example.sub1fundamental.ui.favorite

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.example.sub1fundamental.data.local.database.FavoriteUser
import com.example.sub1fundamental.data.local.database.FavoriteUserDao
import com.example.sub1fundamental.data.local.database.UserDatabase

class FavoriteUserViewModel(application: Application): AndroidViewModel(application) {

    private var userDao: FavoriteUserDao?
    private var userDb: UserDatabase?

    init {
        userDb = UserDatabase.getDatabase(application)
        userDao= userDb?.favoriteUserDao()
    }

    fun getFavoriteUser(): LiveData<List<FavoriteUser>>?{
        return userDao?.getFavoriteUser()
    }
}