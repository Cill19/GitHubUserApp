package com.example.sub1fundamental.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.sub1fundamental.data.local.datastore.DataStoreManager
import kotlinx.coroutines.launch

class ThemeSettingsViewModel(private val prefs: DataStoreManager): ViewModel() {

	fun getTheme() = prefs.getThemeSetting().asLiveData()

	fun saveTheme(isDarkModeActive: Boolean){
		viewModelScope.launch {
			prefs.saveThemeSetting(isDarkModeActive)
		}
	}

	class Factory(private val prefs: DataStoreManager): ViewModelProvider.NewInstanceFactory(){
		override fun <T : ViewModel> create(modelClass: Class<T>): T = ThemeSettingsViewModel(prefs) as T
	}
}