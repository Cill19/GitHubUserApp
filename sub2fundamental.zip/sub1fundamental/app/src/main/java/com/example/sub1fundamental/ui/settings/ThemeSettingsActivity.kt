package com.example.sub1fundamental.ui.settings

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import com.example.sub1fundamental.data.local.datastore.DataStoreManager
import com.example.sub1fundamental.databinding.ActivityThemeSettingsBinding

class ThemeSettingsActivity : AppCompatActivity() {
	private var _binding: ActivityThemeSettingsBinding? = null
	private val binding get() = _binding!!
	private val viewModel: ThemeSettingsViewModel by viewModels {
		ThemeSettingsViewModel.Factory(DataStoreManager(this))
	}

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		_binding = ActivityThemeSettingsBinding.inflate(layoutInflater)
		setContentView(binding.root)

		// Enable the up navigation (back button)
		supportActionBar?.setDisplayHomeAsUpEnabled(true)
		title = "Settings"

		themeSettings()
	}

	private fun themeSettings() {
		viewModel.getTheme().observe(this) { isDarkTheme ->
			val themeText = if (isDarkTheme) "Dark Theme" else "Light Theme"
			binding.switchTheme.text = themeText
			val nightMode =
				if (isDarkTheme) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
			AppCompatDelegate.setDefaultNightMode(nightMode)
			Log.d("THEME", isDarkTheme.toString())
			binding.switchTheme.isChecked = isDarkTheme
		}

		// Use an OnCheckedChangeListener for the switch
		binding.switchTheme.setOnCheckedChangeListener { _, isChecked ->
			viewModel.saveTheme(isChecked)
		}
	}

	override fun onOptionsItemSelected(item: MenuItem): Boolean {
		return when (item.itemId) {
			android.R.id.home -> {
				// Handle the up button click, e.g., navigate back
				onBackPressed()
				true
			}

			else -> super.onOptionsItemSelected(item)
		}
	}

	override fun onDestroy() {
		super.onDestroy()
		_binding = null
	}
}
