package com.example.sub1fundamental.ui.detail

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.sub1fundamental.R
import com.example.sub1fundamental.ui.home.MainActivity
import com.example.sub1fundamental.databinding.ActivityDetailBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.example.sub1fundamental.ui.viewmodel.DetailViewModel

class DetailActivity : AppCompatActivity() {
	companion object {
		@StringRes
		val TAB_TITLES = intArrayOf(
			R.string.following,
			R.string.follower
		)
	}

	private val viewModel by viewModels<DetailViewModel>()

	private var _binding: ActivityDetailBinding? = null
	private val binding get() = _binding!!

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		_binding = ActivityDetailBinding.inflate(layoutInflater)
		setContentView(binding.root)

		val username = intent.getStringExtra(MainActivity.extras_user)

        // Enable the up navigation (back button)
		supportActionBar?.setDisplayHomeAsUpEnabled(true)
		title = username

		username?.let {
			setupViewPager(it)
			setupActionBar()
			viewModel.isloading.observe(this) { showLoading(it) }
			getDetail(it)
		}
	}

	private fun setupViewPager(username: String) {
		val sectionsPagerAdapter = SectionsPagerAdapter(this)
		val viewPager: ViewPager2 = findViewById(R.id.view_pager)
		sectionsPagerAdapter.username = username
		viewPager.adapter = sectionsPagerAdapter

		val tabs: TabLayout = findViewById(R.id.tabs)
		TabLayoutMediator(tabs, viewPager) { tab, position ->
			tab.text = resources.getString(TAB_TITLES[position])
		}.attach()
	}

	private fun setupActionBar() {
		supportActionBar?.elevation = 0f
	}

	@SuppressLint("SetTextI18n")
	private fun getDetail(username: String) {
		viewModel.detailuser(username)
		viewModel.user.observe(this) { data ->
			Glide.with(this).load(data.avatarUrl).into(binding.imgItemPhoto)
			binding.tvDetailName.text = data.name
			binding.tvDetailUsername.text = data.login
			binding.folowing.text = "${data.following} following"
			binding.folowers.text = "${data.followers} followers"
		}
	}

	private fun showLoading(isLoading: Boolean) {
		binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
	}

	override fun onDestroy() {
		super.onDestroy()
		_binding = null
	}

	override fun onOptionsItemSelected(item: MenuItem): Boolean {
		return when (item.itemId) {
			android.R.id.home -> {
				// Handle the up button click, e.g., navigate back
				onBackPressed()
				true
			}

			else -> super.onOptionsItemSelected(item)
		}
	}
}
