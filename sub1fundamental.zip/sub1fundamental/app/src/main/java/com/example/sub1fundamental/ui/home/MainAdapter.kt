package com.example.sub1fundamental.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.sub1fundamental.databinding.ItemUserBinding
import com.example.sub1fundamental.data.remote.response.DetailUserResponse

class MainAdapter(private val listdata:List<DetailUserResponse>) : RecyclerView.Adapter<MainAdapter.ListViewHolder>(){
    private lateinit var onItemClick : OnItemClick
    class ListViewHolder(var binding: ItemUserBinding) : RecyclerView.ViewHolder(binding.root)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val binding = ItemUserBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return ListViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val (login,avatarUrl, id) = listdata[position]
        Glide.with(holder.itemView.context).load(avatarUrl).into(holder.binding.imgItemPhoto)
        holder.binding.tvItemName.text = login
        holder.binding.tvItemId.text = "ID user: ${id.toString()}"
        holder.binding.cvuser.setOnClickListener {
            onItemClick.onitemclicked(listdata[holder.adapterPosition])
        }
    }

    override fun getItemCount(): Int {
        return listdata.size
    }
    fun setOnItemClick(onItemClick: OnItemClick){
        this.onItemClick = onItemClick
    }
    interface OnItemClick {
        fun onitemclicked (data: DetailUserResponse)
    }
}