package com.example.sub1fundamental.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.sub1fundamental.helper.Event
import com.example.sub1fundamental.data.remote.response.DetailUserResponse
import com.example.sub1fundamental.data.remote.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailViewModel: ViewModel() {
    private val _user = MutableLiveData<DetailUserResponse>()
    val user: LiveData<DetailUserResponse> = _user
    private val _follow = MutableLiveData<List<DetailUserResponse>>()
    val follow: LiveData<List<DetailUserResponse>> = _follow
    private val _isloading = MutableLiveData<Boolean>()
    val isloading: LiveData<Boolean> = _isloading
    private val _message = MutableLiveData<Event<String>>()
    val message: LiveData<Event<String>> = _message

    fun detailuser (username:String){
        _isloading.value = true
        val client = ApiConfig.getApiService().getDetailUser(username)
        client.enqueue(object: Callback<DetailUserResponse> {
            override fun onResponse(
                call: Call<DetailUserResponse>,
                response: Response<DetailUserResponse>
            ) {
                _isloading.value = false
                if (response.isSuccessful){
                    _user.value = response.body()
                }
            }

            override fun onFailure(call: Call<DetailUserResponse>, t: Throwable) {
                _isloading.value = false
                _message.value = Event(t.message.toString())
            }
        })
    }
    fun followinguser(username:String){
        _isloading.value = true
        val client = ApiConfig.getApiService().getListFollowing(username)
        client.enqueue(object: Callback<List<DetailUserResponse>> {
            override fun onResponse(
                call: Call<List<DetailUserResponse>>,
                response: Response<List<DetailUserResponse>>
            ) {
                _isloading.value = false
                if (response.isSuccessful){
                    _follow.value = response.body()
                }
            }

            override fun onFailure(call: Call<List<DetailUserResponse>>, t: Throwable) {
                _isloading.value = false
                _message.value = Event(t.message.toString())
            }
        })
    }

    fun followersuser(username:String){
        _isloading.value = true
        val client = ApiConfig.getApiService().getListFollower(username)
        client.enqueue(object: Callback<List<DetailUserResponse>> {
            override fun onResponse(
                call: Call<List<DetailUserResponse>>,
                response: Response<List<DetailUserResponse>>
            ) {
                _isloading.value = false
                if (response.isSuccessful){
                    _follow.value = response.body()
                }
            }

            override fun onFailure(call: Call<List<DetailUserResponse>>, t: Throwable) {
                _isloading.value = false
                _message.value = Event(t.message.toString())
            }
        })
    }
}