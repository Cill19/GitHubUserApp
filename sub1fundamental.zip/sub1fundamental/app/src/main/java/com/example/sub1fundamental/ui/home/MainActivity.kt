package com.example.sub1fundamental.ui.home

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.example.sub1fundamental.data.remote.response.DetailUserResponse
import com.example.sub1fundamental.ui.detail.DetailActivity
import com.example.sub1fundamental.ui.viewmodel.MainViewModel
import com.example.sub1fundamental.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private var _binding: ActivityMainBinding? = null
    private val binding get() = _binding!!
    private val viewModel by viewModels<MainViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        with(binding) {
            searchView.setupWithSearchBar(searchBar)
            searchView
                .editText
                .setOnEditorActionListener { textView, actionId, event ->
                    searchBar.text = searchView.text
                    searchView.hide()
                    binding.progressBar.visibility = View.VISIBLE
                    viewModel.getuser(searchView.text.toString())
                    false
                }
        }
        getResult()
        binding.rvGithub.layoutManager = LinearLayoutManager(this)
        viewModel.message.observe(this) {
            it.getContentIfNotHandled()?.let { text ->
                Snackbar.make(window.decorView.rootView, text, Snackbar.LENGTH_SHORT).show()
            }
        }
        viewModel.isloading.observe(this) { showLoading(it) }
    }

    private fun getResult() {
        viewModel.user.observe(this) { data ->
            val adapter = MainAdapter(data)
            binding.rvGithub.adapter = adapter
            adapter.setOnItemClick(object : MainAdapter.OnItemClick {
                override fun onitemclicked(data: DetailUserResponse) {
                    val intent = Intent(this@MainActivity, DetailActivity::class.java)
                    intent.putExtra(extras_user, data.login)
                    startActivity(intent)
                }
            })
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        binding.rvGithub.visibility = if (!isLoading) View.VISIBLE else View.GONE
    }

    companion object {
        const val extras_user = "extras_user"
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}
