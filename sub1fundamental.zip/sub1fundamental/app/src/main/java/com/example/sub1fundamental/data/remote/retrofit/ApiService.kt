package com.example.sub1fundamental.data.remote.retrofit

import com.example.sub1fundamental.data.remote.response.DetailUserResponse
import com.example.sub1fundamental.data.remote.response.GithubResponse
import retrofit2.Call
import retrofit2.http.*

interface ApiService{
    @GET("search/users")
    fun getSearch(
        @Query("q") username: String
    ): Call<GithubResponse>

    @GET("users/{username}")
    fun getDetailUser(
        @Path("username") username: String
    ): Call<DetailUserResponse>

    @GET("users/{username}/followers")
    fun getListFollower(
        @Path("username") username: String
    ): Call<List<DetailUserResponse>>

    @GET("users/{username}/following")
    fun getListFollowing(
        @Path("username") username: String
    ): Call<List<DetailUserResponse>>
}